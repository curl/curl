char *getpass(const char *prompt);
