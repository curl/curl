#define CURL_NAME "curl"
#define CURL_VERSION "6.3.1"
#define CURL_ID CURL_NAME " " CURL_VERSION " (" OS ") "
