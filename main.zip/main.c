#include <curl/curl.h>
#include <pthread.h>
#include <assert.h>

static pthread_mutex_t connections_locks[CURL_LOCK_DATA_LAST] = {
    PTHREAD_MUTEX_INITIALIZER,
    PTHREAD_MUTEX_INITIALIZER,
    PTHREAD_MUTEX_INITIALIZER,
    PTHREAD_MUTEX_INITIALIZER,
    PTHREAD_MUTEX_INITIALIZER,
    PTHREAD_MUTEX_INITIALIZER,
    PTHREAD_MUTEX_INITIALIZER
};

static void lock_func(CURL *handle, curl_lock_data data, curl_lock_access access, void *userptr)
{
    pthread_mutex_lock(&connections_locks[data]);
}

static void unlock_func(CURL *handle, curl_lock_data data, void *userptr)
{
    pthread_mutex_unlock(&connections_locks[data]);
}

static void do_transfer(CURLSH *share)
{
    CURL *easy = curl_easy_init();
    curl_easy_setopt(easy, CURLOPT_SHARE, share);
    curl_easy_setopt(easy, CURLOPT_URL, "http://google.com/");
    curl_easy_perform(easy);
}

static void* thread_func(void* share)
{
    do_transfer((CURLSH*)share);
}

int main()
{
    curl_global_init(CURL_GLOBAL_ALL);

    CURLSH *share = curl_share_init();
    curl_share_setopt(share, CURLSHOPT_SHARE, CURL_LOCK_DATA_CONNECT);
    curl_share_setopt(share, CURLSHOPT_LOCKFUNC, lock_func);
    curl_share_setopt(share, CURLSHOPT_UNLOCKFUNC, unlock_func);

    pthread_t thread;

    pthread_create(&thread, NULL, thread_func, share);
    do_transfer(share);
    pthread_join(thread, NULL);

    curl_global_cleanup();
    return 0;
}