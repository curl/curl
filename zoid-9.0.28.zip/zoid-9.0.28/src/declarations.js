/* @flow */

declare var __ZOID__ : {
    __VERSION__ : string,
    __GLOBAL_KEY__ : string,
    __POPUP_SUPPORT__ : boolean,
    __FRAMEWORK_SUPPORT__ : boolean,
    __DEFAULT_CONTAINER__ : boolean,
    __DEFAULT_PRERENDER__ : boolean
};
