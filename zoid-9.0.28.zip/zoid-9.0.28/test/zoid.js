/* @flow */

window.zoid = require('../src/index');
