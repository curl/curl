/* @flow */

export const ACCOUNTS = {

    US_BUYER: {
        EMAIL:    '_sys_aquarium-2975350886049504@paypal.com',
        PASSWORD: 'stage2@qa'
    },

    US_BUYER_WITH_CREDIT: {
        EMAIL:    '_sys_aquarium-6623821964517697@paypal.com',
        PASSWORD: 'stage2@qa'
    }
};
