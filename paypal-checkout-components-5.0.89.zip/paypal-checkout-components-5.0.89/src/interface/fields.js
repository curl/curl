/* @flow */

import { getFieldsComponent } from '../zoid/fields/component';

export const Fields = {
    __get__: () => getFieldsComponent()
};
