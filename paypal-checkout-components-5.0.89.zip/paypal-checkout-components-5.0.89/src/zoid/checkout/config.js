/* @flow */

export const DEFAULT_POPUP_SIZE = {
    WIDTH:  500,
    HEIGHT: 590
};
