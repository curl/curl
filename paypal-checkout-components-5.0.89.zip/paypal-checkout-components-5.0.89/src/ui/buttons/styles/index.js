/* @flow */

export { componentStyle } from './base';
